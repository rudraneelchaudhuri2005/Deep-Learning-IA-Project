DL Project: Multi-Horizon PM2.5 Forecasting for Indian Cities

data/raw/city_day_raw.csv       Original dataset as uploaded
data/clean/clean_daily.csv      Cleaned and gap-filled daily data with split labels
data/clean/pm25_windows.npz     Model-ready windows, targets and split indicators
results/                        Result tables, error analysis, training history and test predictions
figures/                        All figures in PNG format
